from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db import transaction
from django.utils import timezone
import json
from .models import Entrada, Produto

def serialize_entrada(entrada):
    return {
        'id': entrada.id,
        'produto_id': entrada.produto.id,
        'produto_nome': entrada.produto.nome,
        'quantidade': entrada.quantidade,
        'data_entrada': entrada.data_entrada.isoformat() if entrada.data_entrada else None,
        'observacoes': entrada.observacoes,
        'created_at': entrada.created_at.isoformat(),
        'updated_at': entrada.updated_at.isoformat(),
    }

@require_http_methods(["GET"])
def index(request):
    page = request.GET.get('page', 1)
    page_size = request.GET.get('pageSize', 5)
    queryset = Entrada.objects.all().order_by('-data_entrada')
    paginator = Paginator(queryset, page_size)
    try:
        data = paginator.page(page)
    except PageNotAnInteger:
        data = paginator.page(1)
    except EmptyPage:
        data = paginator.page(paginator.num_pages)
    serialized_data = [serialize_entrada(entrada) for entrada in data]
    return JsonResponse({
        'message': 'Relatório de Entradas',
        'status': 200,
        'page': int(page),
        'pageSize': int(page_size),
        'total': paginator.count,
        'totalPages': paginator.num_pages,
        'data': serialized_data
    }, status=200)

@csrf_exempt
@require_http_methods(["POST"])
def store(request):
    try:
        data = json.loads(request.body)
        produto_id = data.get('produto_id')
        quantidade = data.get('quantidade')
        if not produto_id or not quantidade:
            return JsonResponse({'message': 'ID do produto e quantidade são obrigatórios.', 'status': 400}, status=400)
        with transaction.atomic():
            produto = get_object_or_404(Produto, pk=produto_id)
            entrada = Entrada.objects.create(
                produto=produto,
                quantidade=quantidade,
                data_entrada=data.get('data_entrada') or timezone.now(),  # <-- Corrigido aqui
                observacoes=data.get('observacoes')
            )
            produto.quantidade += int(quantidade)
            produto.save()
        return JsonResponse({
            'message': 'Entrada de produto registrada com sucesso!',
            'status': 201,
            'data': serialize_entrada(entrada)
        }, status=201)
    except (json.JSONDecodeError, KeyError):
        return JsonResponse({'message': 'Dados de entrada inválidos.', 'status': 400}, status=400)

@require_http_methods(["GET"])
def show(request, pk):
    entrada = get_object_or_404(Entrada, pk=pk)
    return JsonResponse({
        'message': 'Entrada encontrada com sucesso.',
        'status': 200,
        'data': serialize_entrada(entrada)
    }, status=200)

@require_http_methods(["PUT", "PATCH"])
def update(request, pk):
    entrada = get_object_or_404(Entrada, pk=pk)
    try:
        data = json.loads(request.body)
        nova_quantidade = data.get('quantidade')
        if nova_quantidade is not None:
            with transaction.atomic():
                produto = entrada.produto
                produto.quantidade -= entrada.quantidade
                produto.quantidade += nova_quantidade
                produto.save()
                entrada.quantidade = nova_quantidade
        for key, value in data.items():
            if key != 'quantidade':
                setattr(entrada, key, value)
        entrada.save()
        return JsonResponse({
            'message': 'Entrada de produto atualizada com sucesso!',
            'status': 200,
            'data': serialize_entrada(entrada)
        }, status=200)
    except (json.JSONDecodeError, KeyError):
        return JsonResponse({'message': 'Dados de entrada inválidos.', 'status': 400}, status=400)

@require_http_methods(["DELETE"])
def destroy(request, pk):
    entrada = get_object_or_404(Entrada, pk=pk)
    with transaction.atomic():
        produto = entrada.produto
        produto.quantidade -= entrada.quantidade
        produto.save()
        entrada.delete()
    return JsonResponse({
        'message': 'Entrada de produto excluída com sucesso! Quantidade removida do estoque.',
        'status': 200,
        'data': {'id': pk}
    }, status=200)
