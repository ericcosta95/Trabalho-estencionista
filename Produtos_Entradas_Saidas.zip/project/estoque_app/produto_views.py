from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
import json
from .models import Produto
from .log_config import logger

def serialize_produto(produto):
    return {
        'id': produto.id,
        'nome': produto.nome,
        'descricao': produto.descricao,
        'quantidade': produto.quantidade,  # Certifique-se que esta linha existe
        'created_at': produto.created_at.isoformat(),
        'updated_at': produto.updated_at.isoformat(),
    }

@require_http_methods(["GET"])
def index(request):
    page = request.GET.get('page', 1)
    page_size = request.GET.get('pageSize', 5)
    direction = request.GET.get('dir', 'asc')
    property = request.GET.get('props', 'id')
    search = request.GET.get('search', '')
    queryset = Produto.objects.filter(deleted_at__isnull=True)
    if direction == 'desc':
        property = f'-{property}'
    queryset = queryset.order_by(property)
    if search:
        queryset = queryset.filter(nome__icontains=search)
    paginator = Paginator(queryset, page_size)
    try:
        data = paginator.page(page)
    except PageNotAnInteger:
        data = paginator.page(1)
    except EmptyPage:
        data = paginator.page(paginator.num_pages)
    serialized_data = [serialize_produto(produto) for produto in data]
    return JsonResponse({
        'message': 'Relatório de Produtos',
        'status': 200,
        'page': int(page),
        'pageSize': int(page_size),
        'dir': direction,
        'props': property,
        'search': search,
        'total': paginator.count,
        'totalPages': paginator.num_pages,
        'data': serialized_data
    }, status=200)

@csrf_exempt
@require_http_methods(["POST"])
def store(request):
    try:
        data = json.loads(request.body)
        produto = Produto.objects.create(
            nome=data.get('nome'),
            descricao=data.get('descricao')
        )
        return JsonResponse({
            'message': 'Produto criado com sucesso',
            'status': 201,
            'data': serialize_produto(produto)
        }, status=201)
    except Exception as e:
        logger.error(f'Erro ao cadastrar produto: {str(e)}', exc_info=True)
        return JsonResponse({'message': 'Dados de entrada inválidos', 'status': 400}, status=400)

@require_http_methods(["GET"])
def show(request, pk):
    produto = get_object_or_404(Produto, pk=pk)
    return JsonResponse({
        'message': 'Produto encontrado com sucesso',
        'status': 200,
        'data': serialize_produto(produto)
    }, status=200)

@require_http_methods(["PUT", "PATCH"])
def update(request, pk):
    produto = get_object_or_404(Produto, pk=pk)
    try:
        data = json.loads(request.body)
        for key, value in data.items():
            setattr(produto, key, value)
        produto.save()
        return JsonResponse({
            'message': 'Produto atualizado com sucesso',
            'status': 200,
            'data': serialize_produto(produto)
        }, status=200)
    except (json.JSONDecodeError, KeyError):
        return JsonResponse({'message': 'Dados de entrada inválidos', 'status': 400}, status=400)

@require_http_methods(["DELETE"])
def destroy(request, pk):
    produto = get_object_or_404(Produto, pk=pk)
    produto.delete()
    return JsonResponse({
        'message': 'Produto excluído com sucesso',
        'status': 200,
        'data': serialize_produto(produto)
    }, status=200)
