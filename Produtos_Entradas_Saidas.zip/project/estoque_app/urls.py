from django.urls import path
from django.views.generic import TemplateView
from . import produto_views, entrada_views, saida_views, movimentacao_views

urlpatterns = [
    # Rotas para as páginas HTML
    path('', TemplateView.as_view(template_name='dashboard.html'), name='dashboard'),
    path('cadastro_produto/', TemplateView.as_view(template_name='cadastro_produto.html'), name='cadastro_produto'),
    path('entradas/', TemplateView.as_view(template_name='entradas.html'), name='entradas'),
    path('saidas/', TemplateView.as_view(template_name='saidas.html'), name='saidas'),
    path('movimentacoes/', TemplateView.as_view(template_name='movimentacoes.html'), name='movimentacoes'),

    # Rotas para API de Produtos
    path('api/produtos/', produto_views.index, name='api_produtos_list'),
    path('api/produtos/create/', produto_views.store, name='api_produtos_create'),

    # Rotas para API de Entradas
    path('api/entradas/', entrada_views.index, name='api_entrada_list'),
    path('api/entradas/create/', entrada_views.store, name='api_entrada_create'),
    path('api/entradas/<int:pk>/', entrada_views.show, name='api_entrada_detail'),
    path('api/entradas/<int:pk>/update/', entrada_views.update, name='api_entrada_update'),
    path('api/entradas/<int:pk>/delete/', entrada_views.destroy, name='api_entrada_delete'),

    # Rotas para API de Saídas
    path('api/saidas/', saida_views.index, name='api_saidas_list'),  # GET
    path('api/saidas/create/', saida_views.store, name='api_saidas_create'),  # POST
    path('api/saidas/<int:pk>/', saida_views.show, name='api_saidas_detail'),
    path('api/saidas/<int:pk>/update/', saida_views.update, name='api_saidas_update'),
    path('api/saidas/<int:pk>/delete/', saida_views.destroy, name='api_saidas_delete'),

    # Rotas para API de Movimentações
    path('api/movimentacoes/', movimentacao_views.index, name='api_movimentacoes_list'),
]
