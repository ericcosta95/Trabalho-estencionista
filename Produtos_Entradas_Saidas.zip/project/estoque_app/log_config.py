import logging

# Configuração básica do logger
logging.basicConfig(
    filename='django_app.log',
    level=logging.ERROR,
    format='%(asctime)s %(levelname)s %(message)s'
)

logger = logging.getLogger(__name__)
