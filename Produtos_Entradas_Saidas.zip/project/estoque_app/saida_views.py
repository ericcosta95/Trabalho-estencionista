from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db import transaction
from django.utils import timezone
import json
from .models import Saida, Produto

def serialize_saida(saida):
    return {
        'id': saida.id,
        'produto_id': saida.produto.id,
        'produto_nome': saida.produto.nome,
        'quantidade': saida.quantidade,
        'data_saida': saida.data_saida.isoformat() if saida.data_saida else None,
        'observacoes': saida.observacoes,
        'created_at': saida.created_at.isoformat(),
        'updated_at': saida.updated_at.isoformat(),
    }

@require_http_methods(["GET"])
def index(request):
    page = request.GET.get('page', 1)
    page_size = request.GET.get('pageSize', 5)
    queryset = Saida.objects.all().order_by('-data_saida')
    paginator = Paginator(queryset, page_size)
    try:
        data = paginator.page(page)
    except PageNotAnInteger:
        data = paginator.page(1)
    except EmptyPage:
        data = paginator.page(paginator.num_pages)
    serialized_data = [serialize_saida(saida) for saida in data]
    return JsonResponse({
        'message': 'Relatório de Saídas',
        'status': 200,
        'page': int(page),
        'pageSize': int(page_size),
        'total': paginator.count,
        'totalPages': paginator.num_pages,
        'data': serialized_data
    }, status=200)

@csrf_exempt
@require_http_methods(["POST"])
def store(request):
    try:
        data = json.loads(request.body)
        produto_id = data.get('produto_id')
        quantidade = data.get('quantidade')
        if not produto_id or not quantidade:
            return JsonResponse({'message': 'ID do produto e quantidade são obrigatórios.', 'status': 400}, status=400)
        with transaction.atomic():
            produto = get_object_or_404(Produto, pk=produto_id)
            saida = Saida.objects.create(
                produto=produto,
                quantidade=quantidade,
                data_saida=data.get('data_saida') or timezone.now(),  # Garante valor para data_saida
                observacoes=data.get('observacoes')
            )
            produto.quantidade -= int(quantidade)
            produto.save()
        return JsonResponse({
            'message': 'Saída de produto registrada com sucesso!',
            'status': 201,
            'data': {
                'id': saida.id,
                'produto': saida.produto.id,
                'quantidade': saida.quantidade,
                'data_saida': saida.data_saida.isoformat(),
                'observacoes': saida.observacoes,
            }
        }, status=201)
    except Exception as e:
        return JsonResponse({'message': f'Erro ao registrar saída: {str(e)}', 'status': 500}, status=500)

@require_http_methods(["GET"])
def show(request, pk):
    saida = get_object_or_404(Saida, pk=pk)
    return JsonResponse({
        'message': 'Saída encontrada com sucesso.',
        'status': 200,
        'data': serialize_saida(saida)
    }, status=200)

@require_http_methods(["PUT", "PATCH"])
def update(request, pk):
    saida = get_object_or_404(Saida, pk=pk)
    try:
        data = json.loads(request.body)
        nova_quantidade = data.get('quantidade')
        if nova_quantidade is not None:
            with transaction.atomic():
                produto = saida.produto
                produto.quantidade += saida.quantidade
                produto.quantidade -= nova_quantidade
                if produto.quantidade < 0:
                    return JsonResponse({
                        'message': 'Estoque insuficiente para a nova quantidade.',
                        'status': 400
                    }, status=400)
                produto.save()
                saida.quantidade = nova_quantidade
        for key, value in data.items():
            if key != 'quantidade':
                setattr(saida, key, value)
        saida.save()
        return JsonResponse({
            'message': 'Saída de produto atualizada com sucesso!',
            'status': 200,
            'data': serialize_saida(saida)
        }, status=200)
    except (json.JSONDecodeError, KeyError):
        return JsonResponse({'message': 'Dados de entrada inválidos.', 'status': 400}, status=400)

@require_http_methods(["DELETE"])
def destroy(request, pk):
    saida = get_object_or_404(Saida, pk=pk)
    with transaction.atomic():
        produto = saida.produto
        produto.quantidade += saida.quantidade
        produto.save()
        saida.delete()
    return JsonResponse({
        'message': 'Saída de produto excluída com sucesso! Quantidade devolvida ao estoque.',
        'status': 200,
        'data': {'id': pk}
    }, status=200)
