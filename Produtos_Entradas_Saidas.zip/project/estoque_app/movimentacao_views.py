from django.http import JsonResponse
from .models import Entrada, Saida

def index(request):
    entradas = [
        {
            'id': e.id,
            'produto_id': e.produto.id,
            'produto_nome': e.produto.nome,
            'quantidade': e.quantidade,
            'data_entrada': e.data_entrada,
            'observacoes': e.observacoes,
        }
        for e in Entrada.objects.select_related('produto').order_by('-data_entrada')
    ]
    saidas = [
        {
            'id': s.id,
            'produto_id': s.produto.id,
            'produto_nome': s.produto.nome,
            'quantidade': s.quantidade,
            'data_saida': s.data_saida,
            'observacoes': s.observacoes,
        }
        for s in Saida.objects.select_related('produto').order_by('-data_saida')
    ]
    return JsonResponse({
        'entradas': entradas,
        'saidas': saidas
    })