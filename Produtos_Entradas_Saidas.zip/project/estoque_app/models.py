from django.db import models
from django.utils import timezone

# Mixin para simular o SoftDeletes
class SoftDeleteModel(models.Model):
    """
    Um mixin que adiciona um campo `deleted_at` para SoftDeletes.
    """
    deleted_at = models.DateTimeField(null=True, blank=True)

    def delete(self, *args, **kwargs):
        self.deleted_at = timezone.now()
        self.save()

    def hard_delete(self):
        super(SoftDeleteModel, self).delete()
    
    class Meta:
        abstract = True

class Produto(SoftDeleteModel):
    """
    Modelo para representar um produto no estoque.
    """
    nome = models.CharField(max_length=255)
    descricao = models.TextField(null=True, blank=True)
    quantidade = models.IntegerField(default=0, verbose_name="Quantidade em Estoque")

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.nome

class Entrada(SoftDeleteModel):
    """
    Define o modelo de dados para a tabela de entrada de produtos.
    """
    produto = models.ForeignKey(Produto, on_delete=models.CASCADE, verbose_name="Produto")
    quantidade = models.IntegerField(verbose_name="Quantidade")
    data_entrada = models.DateField(verbose_name="Data de Entrada")
    observacoes = models.TextField(blank=True, null=True, verbose_name="Observações")
    
    # Campos para controle de data
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Data de Criação")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Última Atualização")

    def __str__(self):
        return f"Entrada de {self.quantidade} unidades de {self.produto.nome}"

    class Meta:
        verbose_name = "Entrada"
        verbose_name_plural = "Entradas"
        ordering = ['-data_entrada']

class Saida(SoftDeleteModel):
    """
    Define o modelo de dados para a tabela de saída de produtos.
    """
    produto = models.ForeignKey(Produto, on_delete=models.CASCADE, verbose_name="Produto")
    quantidade = models.IntegerField(verbose_name="Quantidade")
    data_saida = models.DateField(verbose_name="Data de Saída")
    observacoes = models.TextField(blank=True, null=True, verbose_name="Observações")
    
    # Campos para controle de data
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Data de Criação")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Última Atualização")

    def __str__(self):
        return f"Saída de {self.quantidade} unidades de {self.produto.nome}"

    class Meta:
        verbose_name = "Saída"
        verbose_name_plural = "Saídas"
        ordering = ['-data_saida']
