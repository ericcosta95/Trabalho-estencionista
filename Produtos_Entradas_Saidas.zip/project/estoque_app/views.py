from django.shortcuts import render
from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db import transaction
import json
from .models import Produto, Entrada, Saida

# Controller para Produto
# Serializador simples para converter objetos de modelo em dicionários
def serialize_produto(produto):
    """Converte um objeto Produto em um dicionário para resposta JSON."""
    return {
        'id': produto.id,
        'nome': produto.nome,
        'descricao': produto.descricao,
        'data_cadastro': produto.data_cadastro.isoformat() if produto.data_cadastro else None,
        'created_at': produto.created_at.isoformat(),
        'updated_at': produto.updated_at.isoformat(),
        'deleted_at': produto.deleted_at.isoformat() if produto.deleted_at else None,
    }

@require_http_methods(["GET"])
def index(request):
    """
    Lista todos os produtos com suporte a paginação, ordenação e busca.
    """
    page = request.GET.get('page', 1)
    page_size = request.GET.get('pageSize', 5)
    direction = request.GET.get('dir', 'asc')
    property = request.GET.get('props', 'id')
    search = request.GET.get('search', '')

    # Base da query: produtos que não foram soft-deletados
    queryset = Produto.objects.filter(deleted_at__isnull=True)

    # Aplica ordenação
    if direction == 'desc':
        property = f'-{property}'
    queryset = queryset.order_by(property)

    # Aplica busca
    if search:
        queryset = queryset.filter(nome__icontains=search)

    paginator = Paginator(queryset, page_size)

    try:
        data = paginator.page(page)
    except PageNotAnInteger:
        data = paginator.page(1)
    except EmptyPage:
        data = paginator.page(paginator.num_pages)
 
    serialized_data = [serialize_produto(produto) for produto in data]

    return JsonResponse({
        'message': 'Relatório de Produtos',
        'status': 200,
        'page': int(page),
        'pageSize': int(page_size),
        'dir': direction,
        'props': property,
        'search': search,
        'total': paginator.count,
        'totalPages': paginator.num_pages,
    'data': serialized_data
    }, status=200)

@require_http_methods(["POST"])
def store(request):
    """
    Cria um novo produto a partir dos dados do request.
    """
    try:
        data = json.loads(request.body)

        # Cria o produto sem a relação com Desenvolvedora
        produto = Produto.objects.create(
            nome=data.get('nome'),
            descricao=data.get('descricao')
        )

        return JsonResponse({
            'message': 'Produto criado com sucesso',
            'status': 201,
            'data': serialize_produto(produto)
        }, status=201)
    except (json.JSONDecodeError, KeyError):
        return JsonResponse({'message': 'Dados de entrada inválidos', 'status': 400}, status=400)

@require_http_methods(["GET"])
def show(request, pk):
    """
    Exibe um único produto pelo seu ID.
    """
    produto = get_object_or_404(Produto, pk=pk)
    return JsonResponse({
        'message': 'Produto encontrado com sucesso',
        'status': 200,
        'data': serialize_produto(produto)
    }, status=200)

@require_http_methods(["PUT", "PATCH"])
def update(request, pk):
    """
    Atualiza um produto existente.
    """
    produto = get_object_or_404(Produto, pk=pk)
    try:
        data = json.loads(request.body)

        # Atualiza os campos do produto sem a relação com Desenvolvedora
        for key, value in data.items():
            setattr(produto, key, value)

        produto.save()

        return JsonResponse({
            'message': 'Produto atualizado com sucesso',
            'status': 200,
            'data': serialize_produto(produto)
        }, status=200)
    except (json.JSONDecodeError, KeyError):
        return JsonResponse({'message': 'Dados de entrada inválidos', 'status': 400}, status=400)

@require_http_methods(["DELETE"])
def destroy(request, pk):
    """
    Realiza o "soft-delete" de um produto.
    """
    produto = get_object_or_404(Produto, pk=pk)
    produto.delete()

    return JsonResponse({
        'message': 'Produto excluído com sucesso',
        'status': 200,
        'data': serialize_produto(produto)
    }, status=200)

# Controller para Entradas
def serialize_entrada(entrada):
    """Converte um objeto Entrada em um dicionário para resposta JSON."""
    return {
        'id': entrada.id,
        'produto_id': entrada.produto.id,
        'produto_nome': entrada.produto.nome,
        'quantidade': entrada.quantidade,
        'data_entrada': entrada.data_entrada.isoformat() if entrada.data_entrada else None,
        'observacoes': entrada.observacoes,
        'created_at': entrada.created_at.isoformat(),
        'updated_at': entrada.updated_at.isoformat(),
    }

@require_http_methods(["GET"])
def index(request):
    """
    Lista todos os registros de entrada com suporte a paginação.
    """
    page = request.GET.get('page', 1)
    page_size = request.GET.get('pageSize', 5)
    
    queryset = Entrada.objects.all().order_by('-data_entrada')
    paginator = Paginator(queryset, page_size)
    
    try:
        data = paginator.page(page)
    except PageNotAnInteger:
        data = paginator.page(1)
    except EmptyPage:
        data = paginator.page(paginator.num_pages)
        
    serialized_data = [serialize_entrada(entrada) for entrada in data]
    
    return JsonResponse({
        'message': 'Relatório de Entradas',
        'status': 200,
        'page': int(page),
        'pageSize': int(page_size),
        'total': paginator.count,
        'totalPages': paginator.num_pages,
        'data': serialized_data
    }, status=200)

@require_http_methods(["POST"])
def store(request):
    """
    Cria um novo registro de entrada e aumenta a quantidade no estoque do produto.
    """
    try:
        data = json.loads(request.body)
        produto_id = data.get('produto_id')
        quantidade = data.get('quantidade')

        if not produto_id or not quantidade:
            return JsonResponse({'message': 'ID do produto e quantidade são obrigatórios.', 'status': 400}, status=400)

        with transaction.atomic():
            produto = get_object_or_404(Produto, pk=produto_id)
            
            entrada = Entrada.objects.create(
                produto=produto,
                quantidade=quantidade,
                data_entrada=data.get('data_entrada'),
                observacoes=data.get('observacoes')
            )
            
            # Aumenta a quantidade no estoque do produto
            produto.quantidade += quantidade
            produto.save()
        
        return JsonResponse({
            'message': 'Entrada de produto registrada com sucesso!',
            'status': 201,
            'data': serialize_entrada(entrada)
        }, status=201)
    except (json.JSONDecodeError, KeyError):
        return JsonResponse({'message': 'Dados de entrada inválidos.', 'status': 400}, status=400)

@require_http_methods(["GET"])
def show(request, pk):
    """
    Exibe um único registro de entrada pelo seu ID.
    """
    entrada = get_object_or_404(Entrada, pk=pk)
    return JsonResponse({
        'message': 'Entrada encontrada com sucesso.',
        'status': 200,
        'data': serialize_entrada(entrada)
    }, status=200)

@require_http_methods(["PUT", "PATCH"])
def update(request, pk):
    """
    Atualiza um registro de entrada existente e ajusta o estoque do produto.
    """
    entrada = get_object_or_404(Entrada, pk=pk)
    try:
        data = json.loads(request.body)
        nova_quantidade = data.get('quantidade')

        if nova_quantidade is not None:
            with transaction.atomic():
                produto = entrada.produto
                # Reverte a quantidade anterior
                produto.quantidade -= entrada.quantidade
                # Aplica a nova quantidade
                produto.quantidade += nova_quantidade
                produto.save()
                entrada.quantidade = nova_quantidade

        for key, value in data.items():
            if key != 'quantidade': # Evita que a quantidade seja sobrescrita antes do cálculo
                setattr(entrada, key, value)
        
        entrada.save()

        return JsonResponse({
            'message': 'Entrada de produto atualizada com sucesso!',
            'status': 200,
            'data': serialize_entrada(entrada)
        }, status=200)
    except (json.JSONDecodeError, KeyError):
        return JsonResponse({'message': 'Dados de entrada inválidos.', 'status': 400}, status=400)

@require_http_methods(["DELETE"])
def destroy(request, pk):
    """
    Remove um registro de entrada e diminui a quantidade do estoque do produto.
    """
    entrada = get_object_or_404(Entrada, pk=pk)
    with transaction.atomic():
        produto = entrada.produto
        # Diminui a quantidade do estoque
        produto.quantidade -= entrada.quantidade
        produto.save()
        entrada.delete()
    
    return JsonResponse({
        'message': 'Entrada de produto excluída com sucesso! Quantidade removida do estoque.',
        'status': 200,
        'data': {'id': pk}
    }, status=200)

# Controller para Saídas
# Serializador simples para converter objetos de modelo em dicionários
def serialize_saida(saida):
    """Converte um objeto Saida em um dicionário para resposta JSON."""
    return {
        'id': saida.id,
        'produto_id': saida.produto.id,
        'produto_nome': saida.produto.nome,
        'quantidade': saida.quantidade,
        'data_saida': saida.data_saida.isoformat() if saida.data_saida else None,
        'observacoes': saida.observacoes,
        'created_at': saida.created_at.isoformat(),
        'updated_at': saida.updated_at.isoformat(),
    }

@require_http_methods(["GET"])
def index(request):
    """
    Lista todos os registros de saída com suporte a paginação.
    """
    page = request.GET.get('page', 1)
    page_size = request.GET.get('pageSize', 5)
    
    queryset = Saida.objects.all().order_by('-data_saida')
    paginator = Paginator(queryset, page_size)
    
    try:
        data = paginator.page(page)
    except PageNotAnInteger:
        data = paginator.page(1)
    except EmptyPage:
        data = paginator.page(paginator.num_pages)
        
    serialized_data = [serialize_saida(saida) for saida in data]
    
    return JsonResponse({
        'message': 'Relatório de Saídas',
        'status': 200,
        'page': int(page),
        'pageSize': int(page_size),
        'total': paginator.count,
        'totalPages': paginator.num_pages,
        'data': serialized_data
    }, status=200)

@require_http_methods(["POST"])
def store(request):
    """
    Cria um novo registro de saída e diminui a quantidade no estoque do produto.
    """
    try:
        data = json.loads(request.body)
        produto_id = data.get('produto_id')
        quantidade = data.get('quantidade')

        if not produto_id or not quantidade:
            return JsonResponse({'message': 'ID do produto e quantidade são obrigatórios.', 'status': 400}, status=400)
        
        with transaction.atomic():
            produto = get_object_or_404(Produto, pk=produto_id)
            
            # Garante que há estoque suficiente para a saída
            if produto.quantidade < quantidade:
                return JsonResponse({
                    'message': 'Estoque insuficiente para a saída do produto.',
                    'status': 400
                }, status=400)
            
            saida = Saida.objects.create(
                produto=produto,
                quantidade=quantidade,
                data_saida=data.get('data_saida'),
                observacoes=data.get('observacoes')
            )
            
            # Diminui a quantidade no estoque do produto
            produto.quantidade -= quantidade
            produto.save()
        
        return JsonResponse({
            'message': 'Saída de produto registrada com sucesso!',
            'status': 201,
            'data': serialize_saida(saida)
        }, status=201)
    except (json.JSONDecodeError, KeyError):
        return JsonResponse({'message': 'Dados de entrada inválidos.', 'status': 400}, status=400)

@require_http_methods(["GET"])
def show(request, pk):
    """
    Exibe um único registro de saída pelo seu ID.
    """
    saida = get_object_or_404(Saida, pk=pk)
    return JsonResponse({
        'message': 'Saída encontrada com sucesso.',
        'status': 200,
        'data': serialize_saida(saida)
    }, status=200)

@require_http_methods(["PUT", "PATCH"])
def update(request, pk):
    """
    Atualiza um registro de saída existente e ajusta o estoque do produto.
    """
    saida = get_object_or_404(Saida, pk=pk)
    try:
        data = json.loads(request.body)
        nova_quantidade = data.get('quantidade')

        if nova_quantidade is not None:
            with transaction.atomic():
                produto = saida.produto
                # Reverte a quantidade anterior
                produto.quantidade += saida.quantidade
                # Aplica a nova quantidade
                produto.quantidade -= nova_quantidade
                
                # Garante que o estoque não fique negativo
                if produto.quantidade < 0:
                     return JsonResponse({
                        'message': 'Estoque insuficiente para a nova quantidade.',
                        'status': 400
                     }, status=400)

                produto.save()
                saida.quantidade = nova_quantidade

        for key, value in data.items():
            if key != 'quantidade': # Evita que a quantidade seja sobrescrita antes do cálculo
                setattr(saida, key, value)
        
        saida.save()

        return JsonResponse({
            'message': 'Saída de produto atualizada com sucesso!',
            'status': 200,
            'data': serialize_saida(saida)
        }, status=200)
    except (json.JSONDecodeError, KeyError):
        return JsonResponse({'message': 'Dados de entrada inválidos.', 'status': 400}, status=400)

@require_http_methods(["DELETE"])
def destroy(request, pk):
    """
    Remove um registro de saída e aumenta a quantidade do estoque do produto.
    """
    saida = get_object_or_404(Saida, pk=pk)
    with transaction.atomic():
        produto = saida.produto
        # Aumenta a quantidade do estoque
        produto.quantidade += saida.quantidade
        produto.save()
        saida.delete()
    
    return JsonResponse({
        'message': 'Saída de produto excluída com sucesso! Quantidade devolvida ao estoque.',
        'status': 200,
        'data': {'id': pk}
    }, status=200)
